package com.example.accessingdatapostgresql;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository
@Transactional
public class EntryDAO {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<Entry> list() {
        String sql = "SELECT * FROM testIGN";

        List<Entry> listSale = jdbcTemplate.query(sql,
                BeanPropertyRowMapper.newInstance(Entry.class));

        return listSale;
    }

    public List<Entry> movies() {
        String sql = "SELECT * FROM testIGN WHERE Media_type = 'Movie'";

        List<Entry> listSale = jdbcTemplate.query(sql,
                BeanPropertyRowMapper.newInstance(Entry.class));

        return listSale;
    }
}