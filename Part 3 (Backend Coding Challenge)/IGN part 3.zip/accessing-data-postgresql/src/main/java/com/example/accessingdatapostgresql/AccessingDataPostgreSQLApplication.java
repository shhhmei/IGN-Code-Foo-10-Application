package com.example.accessingdatapostgresql;

import ch.qos.logback.core.encoder.EchoEncoder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.BatchPreparedStatementSetter;
import org.springframework.jdbc.core.JdbcTemplate;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class AccessingDataPostgreSQLApplication implements CommandLineRunner {

	private static final Logger log = LoggerFactory.getLogger(AccessingDataPostgreSQLApplication.class);

	public static void main(String args[]) {
		SpringApplication.run(AccessingDataPostgreSQLApplication.class, args);
	}

	@Autowired
	JdbcTemplate jdbcTemplate;



	public void run(String... strings) throws Exception {
		log.info("Creating tables");

		jdbcTemplate.execute("DROP TABLE IF EXISTS testIGN");
		jdbcTemplate.execute(
				"CREATE TABLE testIGN(" +
				"id SERIAL, media_type VARCHAR(255), " +
				"name VARCHAR(255)," +
				"shortName VARCHAR(255)," +
				"longDescription TEXT," +
				"shortDescription TEXT," +
				"createdAt VARCHAR(255)," +
				"updatedAt VARCHAR(255)," +
				"reviewUrl VARCHAR(255)," +
				"reviewScore FLOAT," +
				"slug VARCHAR(255)," +
				"genres TEXT[]," +
				"createdBy TEXT[]," +
				"publishedBy TEXT[]," +
				"franchises TEXT[]," +
				"regions TEXT[]" +
						")");

		BufferedReader reader;
		final List<Entry> toInsert = new ArrayList<>();
		try {
			reader = new BufferedReader(new FileReader("/Users/joshuamei/Downloads/codefoobackend_cfgames (2).csv"));
			String line = reader.readLine();
			line = reader.readLine();

			while (line != null) {

				StringBuffer buff = new StringBuffer(line);

				line = reader.readLine();

				while (line != null) {
					String[] temp = line.split(",");

					try {
						double d = Double.parseDouble(temp[0]);
						break;
					} catch (NumberFormatException nfe) {
						buff.append(line);
					}

					line = reader.readLine();
				}

				Entry temp = parse(buff.toString());
				if (temp != null){
					toInsert.add(temp);
				}
			}
			reader.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		log.info("Finished reading file, size: " + toInsert.size());

		//now have list of Entities to be added to database in list toInsert
		Connection conn = jdbcTemplate.getDataSource().getConnection();

		this.jdbcTemplate.batchUpdate(
			"insert into testIGN (id, media_type, name, shortName, longDescription, shortDescription, createdAt, updatedAt," +
					"reviewUrl, reviewScore, slug, genres, createdBy, publishedBy, franchises, regions) values" +
					" (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
			new BatchPreparedStatementSetter() {

					public void setValues(PreparedStatement ps, int i) throws SQLException {

						Array genres = conn.createArrayOf("VARCHAR",
								toInsert.get(i).getGenres());
						Array creators = conn.createArrayOf("VARCHAR",
								toInsert.get(i).getCreatedBy());
						Array publishers = conn.createArrayOf("VARCHAR",
								toInsert.get(i).getPublishedBy());
						Array franchises = conn.createArrayOf("VARCHAR",
								toInsert.get(i).getFranchises());
						Array regions = conn.createArrayOf("VARCHAR",
								toInsert.get(i).getRegions());




						ps.setLong(1, toInsert.get(i).getId());
						ps.setString(2, toInsert.get(i).getMedia());
						ps.setString(3, toInsert.get(i).getName());
						ps.setString(4, toInsert.get(i).getShortName());
						ps.setString(5, toInsert.get(i).getLongDescription());
						ps.setString(6, toInsert.get(i).getShortDescription());
						ps.setString(7, toInsert.get(i).getCreatedAt());
						ps.setString(8, toInsert.get(i).getUpdatedAt());
						ps.setString(9, toInsert.get(i).getReviewUrl());
						ps.setDouble(10, toInsert.get(i).getReviewScore());
						ps.setString(11, toInsert.get(i).getSlug());


						ps.setArray(12, genres);
						ps.setArray(13, creators);
						ps.setArray(14, publishers);
						ps.setArray(15, franchises);
						ps.setArray(16, regions);


					}

					public int getBatchSize() {
						return toInsert.size();
					}

				});
		log.info("Finished");
	}

	private Entry parse(String line) {
		String[] splitted = line.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);

		Entry temp = null;

		try {
			temp = new Entry(Long.parseLong(splitted[0]), splitted[1], splitted[2], splitted[3],
					splitted[4], splitted[5], splitted[6], splitted[7], splitted[8],
					Double.parseDouble(splitted[9]), splitted[10], splitted[11], splitted[12], splitted[13], splitted[14], splitted[15]);
		} catch (Exception ex){
			log.error("Failed to load", ex);
		}

		return temp;
	}

}
