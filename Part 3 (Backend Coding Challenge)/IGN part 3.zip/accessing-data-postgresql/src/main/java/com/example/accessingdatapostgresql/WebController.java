package com.example.accessingdatapostgresql;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController
public class WebController {
    @Autowired
    private EntryDAO dao;

    @RequestMapping("/")
    public String viewHomePage(Model model) {
        List<Entry> listSale = dao.list();
        model.addAttribute("listSale", listSale);
        return "index.html";
    }

    @RequestMapping("/all")
    public String viewAll(Model model) {
        List<Entry> listSale = dao.list();
        StringBuffer sb = new StringBuffer();
        for (Entry e: listSale) {
            sb.append("<br>");

            sb.append(e.getId()).append(") ");
            sb.append("Media Type: ").append(e.getMedia()).append(", ");
            sb.append("Name: ").append(e.getName()).append(", ");
            sb.append("Short Name: ").append(e.getShortName()).append(", ");
            sb.append("Long Description: ").append(e.getLongDescription()).append(", ");
            sb.append("Short Description: ").append(e.getShortDescription()).append(", ");
            sb.append("Created At: ").append(e.getCreatedAt()).append(", ");
            sb.append("Last Updated At: ").append(e.getUpdatedAt()).append(", ");
            sb.append("Review URL: ").append(e.getReviewUrl()).append(", ");
            sb.append("Review Score: ").append(e.getReviewScore()).append(", ");
            sb.append("Slug: ").append(e.getSlug()).append(", ");

            sb.append("Genres: ").append(Arrays.toString(e.getGenres())).append(", ");
            sb.append("Created By: ").append(Arrays.toString(e.getCreatedBy())).append(", ");
            sb.append("Published By: ").append(Arrays.toString(e.getPublishedBy())).append(", ");
            sb.append("Franchises: ").append(Arrays.toString(e.getFranchises())).append(", ");
            sb.append("Regions: ").append(Arrays.toString(e.getRegions())).append(".");


            sb.append("\n");
        }

        return sb.toString();
    }

   @RequestMapping("/movies")
   public String viewMovies() {
       List<Entry> listSale = dao.movies();
       StringBuffer sb = new StringBuffer();
       for (Entry e: listSale) {
           sb.append(e.getId()).append(", ");
           sb.append(e.getName());
           sb.append(System.lineSeparator());
       }

       return sb.toString();

    }

}

