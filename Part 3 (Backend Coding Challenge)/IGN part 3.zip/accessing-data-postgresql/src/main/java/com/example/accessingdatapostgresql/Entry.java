package com.example.accessingdatapostgresql;

import java.sql.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import org.hibernate.annotations.Type;



@Entity
public class Entry {
    @Id
    private long id;
    private String media_type, name, shortName, longDescription, shortDescription, createdAt, updatedAt, reviewUrl, slug;
    private double reviewScore;

    private String[] genres, createdBy, publishedBy, franchises, regions;

    public Entry(long id, String media_type, String name, String shortName, String longDescription, String shortDescription, String createdAt, String updatedAt, String reviewUrl, double reviewScore, String slug, String genres, String createdBy, String publishedBy, String franchises, String regions) {
        setId(id);
        setMedia_type(media_type);
        setName(name);
        setShortName(shortName);
        setLongDescription(longDescription);
        setShortDescription(shortDescription);
        setCreatedAt(createdAt);
        setUpdatedAt(updatedAt);
        setReviewUrl(reviewUrl);
        setReviewScore(reviewScore);
        setSlug(slug);
        setGenres(genres);
        setCreatedBy(createdBy);
        setPublishedBy(publishedBy);
        setFranchises(franchises);
        setRegions(regions);

    }

    public Entry() {
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getMedia() {
        return media_type;
    }

    public void setMedia_type(String media){
        this.media_type = media;
    }

    public String getName() {
        return name;
    }

    public void setName(String name){
        this.name = name;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getLongDescription() {
        return longDescription;
    }

    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getReviewUrl() {
        return reviewUrl;
    }

    public void setReviewUrl(String reviewUrl) {
        this.reviewUrl = reviewUrl;
    }

    public double getReviewScore() {
        return reviewScore;
    }

    public void setReviewScore(double reviewScore) {
        this.reviewScore = reviewScore;
    }

    public String getSlug() {
        return slug;
    }

    public void setSlug(String slug) {
        this.slug = slug;
    }



    public String[] getGenres() {
        return genres;
    }

    private void setGenres(String genres) {
        if (genres == null) {
            return;
        }

        String[] temp = genres.split(",");
        this.genres = temp;
    }

    public void setGenres(Array genres){
        try {
            this.genres = (String[]) genres.getArray();
        } catch (Exception ex) {
            Logger.getLogger(Entry.class.getName()).log(Level.INFO, "error", ex);
        }
    }

    public String[] getCreatedBy() {
        return createdBy;
    }

    private void setCreatedBy(String createdBy) {
        if (createdBy == null) {
            return;
        }

        String[] temp = createdBy.split(",");
        this.createdBy = temp;
    }

    public void setCreatedBy(Array createdBy){
        try {
            this.createdBy = (String[]) createdBy.getArray();
        } catch (Exception ex) {
            Logger.getLogger(Entry.class.getName()).log(Level.INFO, "error", ex);
        }
    }

    public String[] getPublishedBy() {
        return publishedBy;
    }

    private void setPublishedBy(String publishedBy) {
        if (publishedBy == null) {
            return;
        }

        String[] temp = publishedBy.split(",");
        this.publishedBy = temp;
    }

    public void setPublishedBy(Array publishedBy){
        try {
            this.publishedBy = (String[]) publishedBy.getArray();
        } catch (Exception ex) {
            Logger.getLogger(Entry.class.getName()).log(Level.INFO, "error", ex);
        }
    }

    public String[] getFranchises() {
        return franchises;
    }

    private void setFranchises(String franchises) {
        if(franchises == null) return;

        String[] temp = franchises.split(",");
        this.franchises = temp;
    }

    public void setFranchises(Array franchises){
        try {
            this.franchises = (String[]) franchises.getArray();
        } catch (Exception ex) {
            Logger.getLogger(Entry.class.getName()).log(Level.INFO, "error", ex);
        }
    }


    public String[] getRegions() {
        return regions;
    }

    private void setRegions(String regions) {
        if (regions == null) return;

        String[] temp = regions.split(",");
        this.regions = temp;
    }

    public void setRegions(Array regions){
        try {
            this.regions = (String[]) regions.getArray();
        } catch (Exception ex) {
            Logger.getLogger(Entry.class.getName()).log(Level.INFO, "error", ex);
        }
    }

    @Override
    public String toString() {
        return String.format(
                "Entry[id = %d, media type ='%s', name ='%s']",
                id, media_type, name);
    }

    // getters & setters omitted for brevity
}
