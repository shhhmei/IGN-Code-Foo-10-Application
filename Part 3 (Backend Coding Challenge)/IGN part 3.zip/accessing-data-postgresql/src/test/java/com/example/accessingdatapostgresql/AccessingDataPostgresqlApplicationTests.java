package com.example.accessingdatapostgresql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AccessingDataPostgresqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
