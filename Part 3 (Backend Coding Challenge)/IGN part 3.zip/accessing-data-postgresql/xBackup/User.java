package com.example.accessingdatapostgresql;

import javax.persistence.*;
import java.util.ArrayList;

//@Entity // This tells Hibernate to make a table out of this class
//@Table(name = "usertest")
public class User {
    /*
    @Id
    private Integer id;
    private String name;
    private String long_description;
    private String short_description;
    private String created_at;
    private String updated_at;
    private String review_url;
    private double review_score;
    private String slug;
    private String genres;
    private String created_by;
    private String published_by;
    private String franchises;
    private String regions;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
*/

}
